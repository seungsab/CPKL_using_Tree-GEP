
for i000 = 1:size(pop,2)
    figure(1)
    drawtree(pop(i000).tree);
    pause;
end